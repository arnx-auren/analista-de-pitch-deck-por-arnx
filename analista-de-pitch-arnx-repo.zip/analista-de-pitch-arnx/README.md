# Analista de Pitch por ARNx

Plugin para founders de startups **pre-seed y seed** que preparan su pitch a inversores. Basado en el método de pitch de Y Combinator (Michael Seibel): claro y conciso le gana al show.

## Flujo

```
relevamiento → deck → auditor ⇄ deck → guion → qa
```

| Skill | Qué hace | Entregable |
|---|---|---|
| `metodo-pitch` | Base de conocimiento compartida: los 6 bloques, pre-seed vs seed, slide vs voz, versiones del deck | — |
| `relevamiento` | Busca el contexto de la startup (memoria, documentos, correo, reuniones, archivos) y pregunta lo que falta | `pitch/brief.md` |
| `deck` | Genera el prompt para crear el deck en Claude Design con el design system de la startup, y prompts de edición | `pitch/prompt-deck.md` |
| `auditor` | Revisa un deck (PDF/PPTX) contra el método y devuelve correcciones y prompts de edición | `pitch/auditoria.md` |
| `guion` | Tarjetas por slide: concepto a transmitir, qué decir, qué no decir. No redacta el guion | `pitch/guion.md` |
| `qa` | Simula preguntas de inversores, da feedback. Por escrito, dictado o modo voz | `pitch/qa.md` |

## Carpeta de trabajo

Todo vive en `./pitch/` dentro de la carpeta conectada en Cowork. `pitch/estado.md` muestra qué está hecho y el próximo paso. Para empezar: "quiero armar mi pitch".

## Requisitos

- Claude Design habilitado en la cuenta (para crear y editar el deck).
- Conectores opcionales: documentos (Drive), correo, grabador de reuniones. Sin conectores, el relevamiento pregunta.

## Q&A por voz

En Cowork el modo voz no está disponible (solo dictado). Para practicar hablando: preparar el banco de preguntas en Cowork, abrir un chat de Claude (idealmente en el celular), pegar el bloque de sesión que genera la skill `qa` y activar el modo voz. Al terminar, pegar el resumen de vuelta en Cowork para actualizar `qa.md`.

## Instalación

1. Descargá `analista-de-pitch-arnx.plugin` desde la sección **Releases** de este repositorio.
2. En Claude (Cowork), subí el archivo como plugin y confirmá la instalación.
3. Conectá una carpeta de trabajo y escribí: "quiero armar mi pitch".

Para armar el `.plugin` desde el código: comprimí en `.zip` el contenido de este repositorio (incluida la carpeta `.claude-plugin/`) y cambiale la extensión a `.plugin`.

## Principios

- Español siempre.
- Ejecuta; explica el porqué solo si suma, en una línea.
- Nunca inventa números: lo que no tiene fuente queda `[pendiente]`.
- El guion y el Q&A no redactan discursos ni respuestas modelo.

## Crédito

Método basado en la charla de Michael Seibel (Y Combinator) *How To Perfectly Pitch Your Seed Stage Startup* (SaaStr). Adaptación para founders de LATAM por ARNx.

## Licencia

MIT — ver [LICENSE](LICENSE).
