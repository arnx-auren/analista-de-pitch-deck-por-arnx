---
name: auditor
description: Audita un deck de inversores (PDF o PPTX, exportado de Claude Design o previo) contra el método de pitch y devuelve correcciones priorizadas y prompts de edición para Claude Design. Usar cuando el founder diga "revisá mi deck", "auditá la presentación", "¿está bien mi deck?", "qué le cambio", o cuando suba un deck en PDF o PPTX.
---

# Auditor — revisión del deck

Revisar, puntuar y devolver cambios accionables. Todo en español. Directo: el porqué en una línea por hallazgo.

## Paso 1 — Leer

1. Leer el deck (PDF: ver las páginas; PPTX: extraer texto y revisar visualmente si es posible).
2. Leer `pitch/brief.md` si existe. Si no, auditar igual y marcar como "no verificable" cualquier dato numérico.
3. Preguntar la versión si no es evidente: para presentar o para enviar.
4. Leer `metodo-pitch` (`bloques.md`, `slide-vs-voz.md`, `versiones.md`, `etapas.md`).

## Paso 2 — Revisar en 4 niveles

Usar `references/checklist-auditoria.md`:
1. **Global**: slide 1 clara, orden de lo más fuerte a lo más débil, pedido al final, cantidad de slides según versión, bloques faltantes.
2. **Por bloque**: errores típicos de cada bloque.
3. **Diseño**: una idea por slide, legible en 3 segundos, sin elementos que distraigan, títulos-afirmación.
4. **Datos**: cada número contra el brief (coincide / contradice / no está en el brief).

## Paso 3 — Puntuar

Por slide: 🟢 lista · 🟡 ajuste menor · 🔴 cambio necesario. Veredicto global:
- **Lista para usar**: sin 🔴 y máximo 2 🟡.
- **Con cambios**: cualquier 🔴 o más de 2 🟡.
- **Rehacer**: slide 1 no se entiende o faltan qué hacemos / pedido.

## Paso 4 — Entregar

Escribir `pitch/auditoria.md` con `references/plantilla-auditoria.md`:
- Veredicto.
- Top 3 correcciones (las de mayor impacto primero).
- Tabla por slide.
- Prompts de edición para Claude Design (formato de `deck/references/prompts-edicion.md`), uno por cambio.
- Datos faltantes o contradictorios → listarlos para `relevamiento`.

Actualizar `pitch/estado.md`. Responder al founder con veredicto + top 3 + indicación de pegar los prompts en Claude Design y volver a auditar.

## Modo "lectura sin founder"

Para la versión para enviar: además, leer el deck como un inversor que no conoce la startup y anotar en qué slide aparece la primera duda sin responder.

## Reglas

- No rediseñar ni sugerir estética; solo claridad, orden, contenido y datos.
- No proponer datos nuevos: si falta un número, es un pendiente.
- Máximo 3 correcciones prioritarias aunque haya más hallazgos.
