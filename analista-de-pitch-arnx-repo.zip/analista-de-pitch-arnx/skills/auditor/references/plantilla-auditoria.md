# Auditoría del deck — [Startup]
Fecha: · Versión: presentar | enviar · Archivo:

## Veredicto: [Lista para usar | Con cambios | Rehacer]

## Top 3 correcciones
1.
2.
3.

## Por slide
| # | Slide | Estado | Problema | Corrección |
|---|---|---|---|---|
| 1 | | 🟢🟡🔴 | | |

## Datos
| Dato en el deck | Brief | Estado |
|---|---|---|
| | | coincide / contradice / no está |

## Prompts de edición para Claude Design
```
En la slide N, ...
```

## Pendientes para el relevamiento
-
