# Checklist de auditoría

## Global
- [ ] Al terminar la slide 1 se entiende qué hace la empresa
- [ ] Hay ejemplo concreto (en slide o previsto para la voz)
- [ ] Orden de lo más fuerte a lo más débil según la etapa
- [ ] Pedido al final
- [ ] Cantidad de slides: presentar ≈8 / enviar 10–12
- [ ] Están los bloques esperados (y no hay slide de tracción débil)

## Qué hacemos
- [ ] Sin jerga ni texto de la web
- [ ] Claro antes que exhaustivo
## Equipo
- [ ] Cargos · quién programa · logros concretos · sin biografías
## Tracción
- [ ] Cada logro con plazo · gráfico solo si sube · sin "trabajo falso"
## Insight
- [ ] No obvio · con historia · con dato o cita
## Mercado
- [ ] Bottom-up · cuenta visible · comparable · sin informes top-down
## Por qué ahora
- [ ] Cambio concreto, no moda genérica
## Competencia
- [ ] Alternativas reales · diferencial relevante · sin "no tenemos competencia"
## Pedido
- [ ] Monto · hito 18–24 meses · validación de terceros · sin contrataciones

## Diseño
- [ ] Una idea por slide · títulos-afirmación · letra legible · nada decorativo que compita

## Datos
- [ ] Cada número coincide con el brief · ninguno sin fuente
