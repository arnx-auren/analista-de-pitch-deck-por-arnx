# Plantilla de tarjeta

```
SLIDE [N] · [Bloque]                                  ⏱ ~[X] min
Concepto a transmitir: [una línea]
Qué decir:
  · [tema / dato del brief]
  · [tema / dato del brief]
Qué NO decir (sobra):
  · [...]
  · [...]
Cómo: [tono · dónde frenar · pregunta de chequeo]
Si pasa… interés en [X] → [acción] · dispersión → [acción]
Preguntas probables: [pregunta] → dato: [campo del brief]
```

## Ejemplo (tracción, pre-seed)

```
SLIDE 3 · Tracción                                    ⏱ ~1,5 min
Concepto a transmitir: ejecutamos rápido
Qué decir:
  · piloto con 3 estudios en 6 semanas
  · qué aprendimos del piloto (1 punto)
  · métrica de uso más fuerte
Qué NO decir (sobra):
  · la lista de funcionalidades
  · advisors o encuestas como tracción
  · proyecciones
Cómo: afirmativo, frenar después del número y el plazo.
Si pasa… preguntan por el piloto → profundizar ahí · dispersión → saltar al insight
Preguntas probables: ¿pagan? → dato: tracción/ingresos · ¿cuánto usan? → dato: métrica principal
```

## Ejemplo (pedido)

```
SLIDE 8 · Pedido                                      ⏱ ~1 min
Concepto a transmitir: sabemos cuánto necesitamos y para llegar a qué
Qué decir:
  · monto
  · hito a 18 meses
  · quiénes ya entraron
Qué NO decir (sobra):
  · a quién vamos a contratar
  · uso de fondos por área
  · "si les interesa…"
Cómo: pedir explícitamente, mirar a la persona y hacer silencio.
```
