---
name: guion
description: Arma el disparador del guion del pitch: una tarjeta por slide con el concepto a transmitir, qué decir, qué no decir (lo que sobra) y cómo decirlo. No redacta el guion. Usar cuando el founder diga "qué digo en cada slide", "preparame para presentar", "armá el guion", "cómo presento el deck", "qué me sobra al presentar".
---

# Guion — disparadores por slide

**Regla central: no redactar el guion.** Nunca escribir frases para leer o memorizar, en ninguna slide (tampoco en el pedido). Entregar conceptos, puntos y lo que sobra. Si el founder pide el discurso escrito, responder con las tarjetas y explicar en una línea que el pitch funciona como conversación, no como lectura. Todo en español.

## Paso 1 — Leer

1. `pitch/brief.md` (obligatorio; si no existe, derivar a `relevamiento`).
2. El deck final (PDF/PPTX) o, si no está, `pitch/prompt-deck.md`. Preferir el deck auditado; si hay 🔴 en `pitch/auditoria.md`, avisar antes de seguir.
3. `metodo-pitch` (`slide-vs-voz.md`, `bloques.md`).
4. Preguntar la duración de la reunión si no se sabe (por defecto: 10 min de pitch dentro de 30 de reunión).

## Paso 2 — Una tarjeta por slide

Formato de `references/plantilla-tarjeta.md`. Campos:
- **Concepto a transmitir**: lo que el inversor debe pensar al terminar la slide, en una línea.
- **Qué decir**: 2–4 puntos, como temas y datos del brief (no frases).
- **Qué NO decir (sobra)**: 2–4 cosas que son de más en esa slide, según los errores del bloque y lo que ya está a la vista (no leer la slide).
- **Cómo**: tono, duración aproximada, dónde frenar, pregunta de chequeo si corresponde.
- **Si pasa…**: interés → profundizar o saltar a la slide relacionada; dispersión → pasar a lo más fuerte.
- **Preguntas probables**: 1–2, con el dato del brief que responde (sin redactar la respuesta).

Reglas por slide:
- Qué hacemos: el ejemplo concreto va en voz; chequeo "¿se entiende?".
- Equipo: logro + vínculo con el problema, sin biografía.
- Tracción: frenar después del número y el plazo.
- Pedido: puntos = monto, hito, inversores que ya entraron; indicación **pedir explícitamente y hacer silencio**. Sin frase escrita.

## Paso 3 — Cierre de la guía

Agregar al final:
- Tiempo total estimado vs. disponible (bloques de ~2 min).
- Meta: que el inversor hable ≥50% del tiempo; 2–3 momentos donde abrir la conversación.
- Señales a mirar en la cara del inversor.
- Lista de "sobra en todo el pitch" (historia de vida, informes de mercado, contrataciones, features).

## Paso 4 — Entregar

Guardar `pitch/guion.md`, actualizar `pitch/estado.md` y sugerir practicar con `qa`.
