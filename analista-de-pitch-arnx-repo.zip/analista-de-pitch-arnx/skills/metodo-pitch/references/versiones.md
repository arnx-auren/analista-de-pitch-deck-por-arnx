# Versiones del deck

## Para presentar (≈8 slides)
- Acompaña al founder, no lo reemplaza.
- Visualmente sobria: títulos-afirmación, un dato por slide, sin párrafos.
- Orden según etapa y bloque más fuerte.
- Estructura base: portada con qué hacemos · 5–6 bloques · pedido.

## Para enviar (10–12 slides)
- Se lee sin el founder: necesita más texto y contexto.
- Cada slide: título-afirmación + 2–3 líneas de apoyo.
- Incluye siempre por qué ahora y competencia.
- Puede sumar: producto (capturas), modelo de negocio, contacto.

## Error común
Usar un único deck para ambas situaciones: el de presentar queda críptico por mail y el de enviar distrae en la reunión.
