# Bloques: qué va y errores típicos

## 1. Qué hacemos
**Va:** dos oraciones (qué es + cómo gana plata) y un ejemplo específico y memorable.
Ejemplo modelo (Airbnb): "Cualquier dueño puede alquilar su casa online. Cobramos el pago y nos quedamos con ~15%." + un mozo en Washington en 2009, hoteles llenos por la asunción de Obama, cobra US$3–4k y paga meses de alquiler.
**Errores:**
- Usar el lenguaje del cliente (jerga, texto de la web) con inversores. Hacen falta dos versiones.
- Buscar 100% de precisión y perder claridad.
- Ejemplo genérico ("si hay un evento grande podés alquilar").
- Ejemplo que no muestra problema y solución.
- Salir de la slide 1 sin que se entienda qué hace la empresa (slide con solo logo).

## 2. Equipo
**Va:** quién es cada uno, cargo, quién escribe el código, logros y credenciales concretas, cómo vivieron el problema.
**Errores:** sin cargos (¿quién es el CEO?), no decir quién programa, contar historias de vida, omitir logros relevantes (el caso del founder que hizo software del Mars rover y no lo dijo).

## 3. Tracción
**Va:** lo logrado desde que empezaron + plazo. Se puede tener tracción antes de lanzar (MVP con 100 usuarios en 1 mes).
**Errores:** listar logros sin plazo; "trabajo falso" (advisors, encuestas); gráfico que no sube; poner una slide de tracción débil (peor que no tenerla).

## 4. Insight único
**Va:** lo no obvio aprendido sobre el problema, el cliente o la solución. Solo tiene valor si antes quedó claro qué hacen y el equipo convenció.
Ejemplo modelo (Airbnb): procesar el pago como tercero genera confianza entre desconocidos y destraba el marketplace; se aprendió en un viaje sin efectivo y un anfitrión desconfiado.
**Errores:** insight que la mayoría compartiría; sin historia concreta; sin números ni citas.

## 5. Mercado
**Va:** cantidad de clientes posibles × precio, y por qué ese precio; comparable ("X cobra tanto, nosotros tanto, por esto").
**Errores:** citar informes top-down; no mostrar la cuenta; no dar comparables.

## 6. Pedido
**Va:** monto, hito de ingresos o uso a 18–24 meses, validación de terceros (quiénes invirtieron, cuánto se levantó).
**Errores:** no pedir (≈70% de los pitches); no mostrar validación; hablar de contrataciones en vez de hitos; no tener definida la meta.
**Por qué pedir:** hay inversores que, si les piden, invierten porque decir que no les resulta incómodo (sobre todo ángeles). Solo pasa si se pide.

## 7. Por qué ahora
**Va:** el cambio (tecnológico, regulatorio, de comportamiento, de costos) que abre la oportunidad hoy.
**Errores:** "la IA está de moda" sin especificar qué habilita concretamente.

## 8. Competencia
**Va:** alternativas reales (incluida "Excel" o "no hacer nada") y el diferencial que importa al cliente.
**Errores:** "no tenemos competencia"; cuadrantes armados para quedar arriba a la derecha sin sustento.

## Errores globales
- No ordenar de lo más fuerte a lo más débil.
- Presentar como exposición oral en vez de conversación.
- No mirar al inversor.
- Slides que distraen; delegar al diseñador qué resaltar.
