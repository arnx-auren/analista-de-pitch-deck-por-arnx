# Pre-seed vs seed

| | Pre-seed | Seed |
|---|---|---|
| Qué se evalúa | Equipo + insight | Velocidad de ejecución: tracción temprana |
| Tracción | Opcional; vale avance real con plazo (entrevistas, MVP, pilotos, lista de espera). Si es débil, sin slide | Obligatoria, con números y plazo; gráfico solo si sube |
| Insight | Es lo más importante; debe venir de hablar con clientes | Validado con datos de uso |
| Mercado | Bottom-up simple | Bottom-up con precio real y comparables |
| Pedido | Monto chico; hito de validación (primeros clientes pagos, PMF inicial) | Hito de ingresos o uso a 18–24 meses que deje lista la Serie A |
| Inversor típico | Ángeles → pedir explícitamente pesa aún más | Fondos seed + ángeles |

## Cómo definir la etapa
- Sin ingresos recurrentes o con pilotos → pre-seed.
- Con clientes pagos recurrentes y crecimiento medible → seed.
- Si el founder ya la definió, respetar su definición y solo marcar inconsistencias.
