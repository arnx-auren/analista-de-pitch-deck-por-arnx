# Qué va en la slide y qué se dice

Regla: **la slide tiene el dato que se recuerda; la voz tiene la historia y el porqué.** Una idea por slide, legible en 3 segundos. Si el inversor lee, no escucha.

| Bloque | En la slide | En la voz |
|---|---|---|
| Qué hacemos | Una frase grande | Las dos oraciones y el ejemplo con historia |
| Equipo | Foto, nombre, cargo, 1–2 logros | El vínculo con el problema, en una línea |
| Tracción | Número clave + plazo | Por qué impresiona, qué se aprendió |
| Insight | La afirmación en una frase | La anécdota y la cita del cliente |
| Mercado | La cuenta visible y el comparable | Por qué ese precio y esa cantidad |
| Por qué ahora | El cambio en una frase | Cómo ese cambio los afecta |
| Competencia | Alternativas + diferencial | Por qué el cliente los elige |
| Pedido | Monto, hito, inversores | El pedido explícito, en voz alta |

Prueba de la slide 1: si alguien la ve sin audio, tiene que entender qué hace la empresa.
