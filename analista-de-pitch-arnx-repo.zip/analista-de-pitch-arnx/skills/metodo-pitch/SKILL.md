---
name: metodo-pitch
description: Base de conocimiento del plugin sobre cómo pitchear a inversores en pre-seed y seed (método Y Combinator / Michael Seibel). Usar cuando el founder pregunte "qué va en un pitch", "cómo ordeno el deck", "qué diferencia hay entre pre-seed y seed", "qué pongo en la slide y qué digo", "cuántas slides", o cuando otra skill del plugin (relevamiento, deck, auditor, guion, qa) necesite el criterio del método.
---

# Método de pitch — núcleo

Fuente única del criterio. Las demás skills leen este archivo y sus referencias para no contradecirse. Responder siempre en español, directo, sin mentorear: explicar el porqué en una línea solo si suma.

## Principio rector

Destacarse siendo **conciso y fácil de entender**. No hace falta energía ni show. Si el inversor no entiende qué hace la empresa, no puede invertir, y eso es responsabilidad del founder. Regla: **80% preciso, 100% claro**.

## Los 6 bloques (más 2 para LATAM)

1. **Qué hacemos**: dos oraciones + un ejemplo concreto (persona, lugar, momento, resultado). El ejemplo muestra problema y solución sin slide aparte.
2. **Equipo**: nombre, cargo, quién programa, logro concreto, vínculo personal con el problema. Sin historias de vida.
3. **Tracción**: qué se logró **y en cuánto tiempo**. Lo que se evalúa es la velocidad de ejecución. Gráfico solo si sube. Tracción débil → sin slide.
4. **Insight único**: algo no obvio (si la mayoría estaría de acuerdo, no es único), con la historia de cómo se descubrió y datos o citas de clientes.
5. **Mercado**: cálculo bottom-up (clientes × precio), mostrando la cuenta, con un comparable de precio. Nada de informes top-down.
6. **Pedido**: monto + hito de ingresos o uso a 18–24 meses + inversores que ya entraron. Pedir explícitamente. No hablar de contrataciones.
7. **Por qué ahora** (agregado LATAM): qué cambió que hace posible o urgente esto hoy.
8. **Competencia** (agregado LATAM): alternativas actuales y por qué se gana.

## Orden

- **Qué hacemos** siempre primero; **pedido** siempre último.
- En el medio, **de lo más fuerte a lo más débil**. Cada 2 minutos hay que ganarse los 2 siguientes.
- Pre-seed: qué hacemos → equipo → insight → tracción (si hay) → por qué ahora → mercado → competencia → pedido.
- Seed: qué hacemos → tracción → equipo → insight → por qué ahora → mercado → competencia → pedido.
- Ajustar según el bloque más fuerte de la startup concreta.

## Cómo presentar

- Es una conversación, no una exposición: el inversor se convence solo; meta, que hable ≥50% del tiempo.
- Si hay interés en un tema, profundizar o saltar a esa slide. Nunca "ya llego a eso".
- Mirar la cara del inversor (en Zoom se ve todo).
- Slides visualmente sobrias: la atención va al founder.
- Después de "qué hacemos", chequear: "¿se entiende o sirve otro ejemplo?".

## Referencias

- `references/bloques.md` — qué va y errores típicos, bloque por bloque.
- `references/etapas.md` — diferencias pre-seed vs seed.
- `references/slide-vs-voz.md` — qué va en la slide y qué se dice.
- `references/versiones.md` — deck para presentar vs deck para enviar.
