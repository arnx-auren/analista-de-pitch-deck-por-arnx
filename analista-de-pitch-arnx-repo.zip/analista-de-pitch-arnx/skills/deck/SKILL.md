---
name: deck
description: Genera el prompt para crear el deck de inversores en Claude Design usando el design system de la startup, y prompts de edición por slide. Usar cuando el founder diga "armá el deck", "creá la presentación", "prompt para Claude Design", "cambiá la slide X", "ajustá el deck", "versión para enviar por mail" o "versión para presentar".
---

# Deck — prompt para Claude Design

Claude Design crea y edita el deck (facilita que el founder lo modifique después). Esta skill no diseña: escribe el prompt que el founder pega en Claude Design. Sin co-branding: se usa solo el design system de la startup. Todo en español.

## Paso 1 — Leer el brief

1. Leer `pitch/brief.md`. Si no existe, derivar a `relevamiento` y parar.
2. Si faltan imprescindibles (qué hacemos, ejemplo, monto, hito, equipo con cargos), listarlos y derivar a `relevamiento`. No completar con supuestos.
3. Leer `metodo-pitch` (`slide-vs-voz.md`, `versiones.md`).

## Paso 2 — Definir versión y design system

Preguntar con AskUserQuestion (una sola ronda):
- Versión: **para presentar** (≈8 slides, sobria) o **para enviar** (10–12, con texto de contexto). Si pide ambas, generar dos prompts.
- ¿La startup ya tiene design system en Claude Design? Si no, entregar primero los pasos de `references/design-system.md` y esperar confirmación antes de generar el prompt.

## Paso 3 — Armar el prompt

Seguir `references/plantilla-prompt.md`:
- Contexto: startup, etapa, audiencia, versión, cantidad de slides, idioma español.
- Design system: "Usá el design system de [startup]". Sin otras marcas.
- Una sección por slide en el orden del diagnóstico del brief:
  - **Título-afirmación** (no tema: "Pilotos con 3 estudios en 6 semanas", no "Tracción").
  - **Contenido visible**: el dato o frase exacta del brief.
  - **No incluir**: lo que sobra según `bloques.md`.
- Reglas de diseño (fijas, ver plantilla).
- "Usá solo los datos indicados. No agregues cifras, logos de clientes ni testimonios que no estén acá."
- Omitir la slide de tracción si el brief marca que no conviene mostrarla.
- Campos `[pendiente]` → no se incluyen en el prompt; avisar al founder.

## Paso 4 — Entregar

1. Guardar en `pitch/prompt-deck.md`: el prompt en un bloque de código para copiar + el checklist de `references/checklist-resultado.md`.
2. Actualizar `pitch/estado.md`.
3. Indicar al founder: pegar el prompt en un proyecto nuevo de Claude Design con el design system de la startup, adjuntar `brief.md` como referencia, revisar con el checklist, exportar a PDF o PPTX y pedir la auditoría (skill `auditor`).

## Modo edición

Cuando el founder pide cambios o la auditoría devuelve correcciones, generar prompts cortos y específicos, uno por cambio, con el formato de `references/prompts-edicion.md`. Agregarlos al final de `pitch/prompt-deck.md` con fecha.
