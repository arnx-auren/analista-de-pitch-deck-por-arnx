# Checklist para revisar lo que devolvió Claude Design

- [ ] La slide 1 se entiende sin audio: queda claro qué hace la empresa
- [ ] Orden igual al del brief; el pedido al final
- [ ] Títulos como afirmaciones
- [ ] Todos los números coinciden con el brief; no apareció ninguno nuevo
- [ ] Equipo con cargos y quién programa
- [ ] Tracción con plazo (o sin slide, si así se definió)
- [ ] Mercado con la cuenta visible
- [ ] Pedido con monto + hito
- [ ] Nada decorativo que distraiga; letra legible
- [ ] Solo la marca de la startup
- [ ] Cantidad de slides acorde a la versión

Si todo está OK: exportar a PDF o PPTX y pedir la auditoría.
