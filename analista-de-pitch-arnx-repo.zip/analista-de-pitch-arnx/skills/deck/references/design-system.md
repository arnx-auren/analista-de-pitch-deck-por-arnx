# Crear el design system de la startup en Claude Design

Pasos para el founder (entregar en este orden):
1. Abrir Claude Design (requiere plan con acceso; en cuentas Enterprise lo habilita el admin).
2. Crear un design system nuevo con el nombre de la startup.
3. Cargar lo que tenga: web de la startup (captura web), logo, manual de marca, un deck o documento con la identidad, y el código del producto si existe.
4. Revisar que tome colores, tipografías y logo correctos. Corregir lo que falte.
5. Confirmar a Claude que el design system está listo y cómo se llama.

Si la startup no tiene identidad definida: pedir logo + 1–2 colores + una tipografía y armar un design system mínimo. Priorizar legibilidad sobre estética.
