# Plantilla del prompt para Claude Design

````
Creá un deck para inversores de [STARTUP], una startup [pre-seed | seed] de [vertical].
Audiencia: [inversores ángeles | fondos seed] en LATAM.
Versión: [para presentar en reunión — el founder lo acompaña hablando | para enviar por mail — se lee sin el founder].
Cantidad de slides: [N]. Idioma: español.

Design system: usá el design system de [STARTUP]. No uses otras marcas ni co-branding.

Reglas de diseño:
- Una idea por slide, que se entienda en 3 segundos.
- Títulos como afirmaciones, no como temas.
- Letra grande. Sin fondos decorativos, sin imágenes de stock, sin íconos de relleno.
- Gráficos solo donde se indica y solo si la curva sube.
- [Presentar] Máximo 1 dato o frase principal por slide, sin párrafos.
- [Enviar] Título + 2–3 líneas de apoyo por slide.
- Usá solo los datos indicados. No agregues cifras, logos de clientes ni testimonios que no estén acá.

Slides:

1. [Título-afirmación: qué hacemos en una frase]
   Contenido visible: [oración 1]. [oración 2 — solo en versión enviar]
   No incluir: slogans, solo el logo, jerga técnica.

2. [Título-afirmación]
   Contenido visible: [...]
   No incluir: [...]

...

N. [Título-afirmación del pedido: "Levantamos US$X para llegar a Y en 18 meses"]
   Contenido visible: monto · hito · inversores que ya entraron.
   No incluir: plan de contrataciones, uso de fondos por área.
````

## Contenido visible por bloque (guía)

| Bloque | Presentar | Enviar (agrega) |
|---|---|---|
| Qué hacemos | Frase grande | Las dos oraciones + ejemplo en 2 líneas |
| Equipo | Foto, nombre, cargo, 1 logro | Vínculo con el problema |
| Tracción | Número + plazo (gráfico si sube) | Contexto del logro |
| Insight | Afirmación | Historia breve + dato |
| Por qué ahora | El cambio | Consecuencia para el cliente |
| Mercado | Cuenta clientes × precio = total | Comparable y fuente del precio |
| Competencia | Alternativas + diferencial | Tabla simple |
| Pedido | Monto, hito, inversores | Instrumento, contacto |
