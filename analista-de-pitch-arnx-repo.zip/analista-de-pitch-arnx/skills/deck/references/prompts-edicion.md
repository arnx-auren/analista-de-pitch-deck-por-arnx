# Prompts de edición para Claude Design

Formato: un cambio por prompt, citando la slide por número y el cambio exacto.

```
En la slide [N], cambiá el título a "[nuevo título]".
```
```
En la slide [N], reemplazá el contenido por: "[texto]". Quitá [elemento].
```
```
Mové la slide [N] para que quede después de la slide [M].
```
```
Eliminá la slide [N].
```
```
En la slide [N], convertí la lista en un único dato grande: "[dato]".
```
```
En la slide [N], agregá un gráfico de línea con estos valores: [valores del brief]. Sin decoración.
```

Reglas: nunca pedir "mejorá la slide" sin decir qué; nunca incluir datos que no estén en el brief.
