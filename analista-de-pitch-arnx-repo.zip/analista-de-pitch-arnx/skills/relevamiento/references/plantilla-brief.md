# Brief del pitch — [Startup]

> Cada campo: valor · fuente · confianza (alta / media / pendiente). Nunca inventar números.
> Última actualización: [fecha]

## Datos generales
- Startup:
- Web:
- Etapa: pre-seed | seed
- Vertical / tipo de cliente:
- Design system en Claude Design: sí | no | [nombre]

## 1. Qué hacemos
- Oración 1 (qué es):
- Oración 2 (cómo gana plata):
- Ejemplo concreto (persona, lugar, momento, resultado):

## 2. Equipo
| Nombre | Cargo | ¿Programa? | Logro clave | Vínculo con el problema | Fuente |
|---|---|---|---|---|---|

## 3. Tracción
| Logro | Plazo (desde / en cuánto) | Fuente | Confianza |
|---|---|---|---|
- Inicio del proyecto:
- Métrica principal y evolución:

## 4. Insight único
- Afirmación no obvia:
- Historia de cómo se descubrió:
- Dato o cita de cliente:

## 5. Mercado
- Clientes posibles (cantidad y cómo se calculó):
- Precio (y por qué):
- Cuenta: clientes × precio = total
- Comparable y precio:

## 6. Por qué ahora

## 7. Competencia
- Alternativas actuales (incluye "no hacer nada"):
- Diferencial:

## 8. Pedido
- Monto:
- Instrumento (si se sabe):
- Hito a 18–24 meses (ingresos o uso):
- Inversores que ya entraron / compromisos:

## Diagnóstico
- Bloque más fuerte:
- Bloque más débil:
- Orden recomendado:
- Qué no mostrar:
- Incoherencias detectadas:

## Preguntas y objeciones ya recibidas de inversores

## Pendientes
- [ ]

## Historial
- [fecha] — creado
