# Estado del pitch — [Startup]

| Entregable | Estado | Próximo paso |
|---|---|---|
| Brief (`brief.md`) | ⬜ | Relevamiento |
| Prompt del deck (`prompt-deck.md`) | ⬜ | Requiere brief |
| Auditoría (`auditoria.md`) | ⬜ | Requiere deck exportado de Claude Design |
| Guion (`guion.md`) | ⬜ | Requiere deck auditado |
| Q&A (`qa.md`) | ⬜ | Requiere brief |

Estados: ⬜ vacío · 🟡 en progreso · ✅ listo

**Próximo paso:** 
