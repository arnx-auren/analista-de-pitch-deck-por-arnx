# Checklist del relevamiento

## Imprescindibles (sin esto no se arma el deck)
- [ ] Qué hacemos en dos oraciones
- [ ] Ejemplo concreto de un cliente real
- [ ] Monto a levantar
- [ ] Hito a 18–24 meses
- [ ] Equipo con cargos y quién programa

## Importantes
- [ ] Tracción con plazos (o confirmación de que no hay)
- [ ] Insight + historia + dato
- [ ] Clientes posibles × precio
- [ ] Comparable de precio
- [ ] Etapa

## Complementarios
- [ ] Por qué ahora
- [ ] Competencia y diferencial
- [ ] Inversores que ya entraron
- [ ] Preguntas y objeciones recibidas antes
- [ ] Design system en Claude Design

## Señales de alerta (marcar en el diagnóstico)
- Tracción sin plazo
- Mercado citado de un informe
- Pedido que habla de contrataciones
- Insight que "todos saben"
- Ejemplo genérico
