---
name: relevamiento
description: Primer paso del Analista de Pitch por ARNx. Releva el contexto de la startup del founder y escribe el brief del pitch. Usar cuando el founder diga "quiero armar mi pitch", "arrancar", "preparar la ronda", "preparar la reunión con inversores", "actualizar el brief", "cómo voy", "qué falta", o cuando otra skill necesite el brief y no exista la carpeta pitch/ o falten datos.
---

# Relevamiento — el brief del pitch

Objetivo: tener todo el contexto antes de armar nada. Buscar primero, preguntar después. Escribir en español. Ejecutar sin mentorear; explicar el porqué solo en una línea si suma.

## Paso 0 — Carpeta de trabajo

1. Buscar `./pitch/` en la carpeta conectada. Si no existe, crearla con `brief.md` (desde `references/plantilla-brief.md`) y `estado.md` (desde `references/plantilla-estado.md`).
2. Si ya existe, leer `brief.md` y `estado.md` y continuar donde quedó. Si el founder preguntó "cómo voy", mostrar `estado.md` y el próximo paso, y terminar.

## Paso 1 — Buscar antes de preguntar

Buscar en todas las fuentes disponibles del founder; no fallar si alguna no está:
- Memoria de Claude sobre el founder y su startup.
- Archivos que haya subido o que estén en la carpeta conectada: decks anteriores, one-pagers, métricas, planillas.
- Conector de documentos (ej. Drive): "deck", "pitch", "one pager", "métricas", "modelo financiero", nombre de la startup.
- Conector de correo: hilos con inversores, updates a inversores, cierres de clientes.
- Conector o archivos de reuniones (grabador, transcripciones): llamadas con clientes (insights, citas) e inversores (preguntas y objeciones ya recibidas).
- Web pública de la startup (para qué hacen, no para el pitch a inversores).

Para cada dato encontrado registrar **fuente** y **confianza** (alta: documento o dato del founder; media: inferido o desactualizado; pendiente: sin fuente).

## Paso 2 — Detectar qué falta

Recorrer el checklist de `references/checklist.md`. Priorizar faltantes así: qué hacemos → pedido → tracción → equipo → insight → mercado → por qué ahora → competencia.

## Paso 3 — Preguntar lo que falta

- Usar AskUserQuestion, en rondas de **máximo 4 preguntas**, empezando por lo prioritario.
- Preguntar concreto ("¿Cuántos clientes pagos tienen y desde cuándo?"), nunca abierto ("contame de la tracción").
- Mostrar lo encontrado para que el founder lo confirme en vez de volver a preguntarlo.
- Si el founder no sabe un dato, dejarlo `[pendiente]`. **Nunca inventar ni estimar números.**
- Pedir el ejemplo concreto de "qué hacemos" como historia real de un cliente (persona, lugar, momento, resultado).

## Paso 4 — Diagnóstico

Con `metodo-pitch` (referencias `etapas.md` y `bloques.md`):
- Definir etapa: pre-seed o seed.
- Identificar el bloque más fuerte y el más débil.
- Proponer orden de slides.
- Marcar qué no mostrar (ej. tracción débil → sin slide).
- Señalar incoherencias (ej. pedido sin hito, mercado top-down, insight que no es único).

## Paso 5 — Escribir y cerrar

1. Completar `pitch/brief.md` con la plantilla. Cada campo: valor · fuente · confianza.
2. Actualizar `pitch/estado.md`.
3. Responder al founder con: resumen de 5 líneas del diagnóstico, lista de pendientes y próximo paso (normalmente la skill `deck`).

## Actualizaciones

Si el founder trae datos nuevos o otra skill (auditor, qa) detecta faltantes, actualizar solo los campos afectados, conservar fuentes anteriores y registrar la fecha en el historial del brief.
