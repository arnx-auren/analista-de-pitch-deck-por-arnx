# Q&A — [Startup]

## Sesión [fecha] · modo: [rápida | bloque | difícil] · canal: [escrito | dictado | voz]
| # | Pregunta | Puntaje | Qué faltó |
|---|---|---|---|

**Temas a reforzar:**
1.
2.
3.

**Datos faltantes (→ relevamiento):**
-

**Para sumar al deck o al guion:**
-

## Historial de temas débiles
- [fecha] —
