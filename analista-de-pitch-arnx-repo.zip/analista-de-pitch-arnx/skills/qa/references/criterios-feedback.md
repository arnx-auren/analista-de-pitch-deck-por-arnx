# Criterios de feedback

Evaluar cada respuesta en 4 puntos:
1. **Concisa**: responde en 30–60 segundos (o 3–5 líneas escritas); primero la respuesta, después el contexto.
2. **Concreta**: usa un número, un plazo o un ejemplo real.
3. **Pertinente**: responde lo que se preguntó, sin desviarse.
4. **Abre conversación**: deja espacio para que el inversor siga (no cierra con un monólogo).

Puntaje: 🟢 cumple 4 · 🟡 cumple 2–3 · 🔴 cumple 0–1 o contradice el brief.

Formato del feedback (máximo 3 líneas):
- ✔ lo que funcionó
- ✖ lo que faltó o sobró
- → dato del brief a usar: [campo]

Nunca escribir la respuesta ideal completa.
