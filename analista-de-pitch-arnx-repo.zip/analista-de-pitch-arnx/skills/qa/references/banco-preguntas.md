# Banco de preguntas base

Adaptar cada una con datos del brief. Usar lenguaje de inversor, directo.

## Qué hacemos / producto
- ¿Quién es exactamente tu cliente y quién paga?
- ¿Qué usan hoy en lugar de ustedes?
- ¿Por qué esto no lo hace [jugador grande]?

## Equipo
- ¿Quién programa? ¿Hay dependencia de terceros?
- ¿Están full time? ¿Cómo se reparte el equity?
- ¿Qué les falta en el equipo?

## Tracción
- ¿Cuántos clientes pagan y desde cuándo?
- ¿Cuál es la retención / el uso semanal?
- ¿Cómo consiguieron los primeros clientes? ¿Se repite?
- (pre-seed) ¿Qué validaron y en cuánto tiempo?
- (seed) ¿Cuál es el crecimiento mensual de los últimos 6 meses?

## Insight
- ¿Qué saben ustedes que el resto no?
- ¿Qué los sorprendió al hablar con clientes?

## Mercado
- ¿Cómo calcularon ese mercado?
- ¿Por qué ese precio? ¿Lo pagaron?
- ¿Cómo escalan fuera de Argentina?

## Por qué ahora / competencia
- ¿Por qué ahora y no hace 3 años?
- ¿Qué pasa si [competidor] copia esto?
- ¿Cuál es la ventaja defendible?

## Pedido y ronda
- ¿Qué valuación / condiciones buscan?
- ¿Cuántos meses de runway les da?
- ¿Qué tiene que pasar para la próxima ronda?
- ¿Quién más está en la ronda?

## Objeciones (modo difícil)
- "Parece una feature, no una empresa."
- "El mercado es chico."
- "Es muy temprano para nosotros."
- "Me preocupa la dependencia de un solo cliente."
- "No veo cómo se defienden de los grandes."
