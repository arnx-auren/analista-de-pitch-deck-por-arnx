---
name: qa
description: Simula el Q&A con inversores para que el founder practique: arma el banco de preguntas desde el brief, pregunta de a una, da feedback y registra los temas a reforzar. Funciona por escrito, con dictado en Cowork, o en modo voz en un chat de Claude. Usar cuando el founder diga "practicar preguntas", "simulá un inversor", "preparame para el Q&A", "hacé de inversor", "qué me van a preguntar", "practicar por voz".
---

# Q&A — práctica con inversor simulado

Todo en español. **No redactar respuestas modelo**: dar puntos clave y el dato del brief que falta usar.

## Paso 1 — Preparar

1. Leer `pitch/brief.md` (si no existe, derivar a `relevamiento`), `pitch/guion.md` y `pitch/qa.md` si existen.
2. Armar el banco con `references/banco-preguntas.md`:
   - 40% sobre los puntos débiles del diagnóstico.
   - 30% típicas de la etapa (pre-seed o seed).
   - 20% sobre datos `[pendiente]` o de confianza media.
   - 10% preguntas u objeciones ya recibidas (brief) o temas débiles de sesiones anteriores (`qa.md`).
3. Preguntar con AskUserQuestion:
   - Modo: **ronda rápida** (10 preguntas) · **por bloque** · **inversor difícil** (repreguntas y objeciones).
   - Canal: **escrito / dictado en Cowork** · **voz en chat de Claude**.

## Paso 2A — Escrito o dictado (en Cowork)

- Hacer una pregunta por vez, como inversor, sin explicar por qué se pregunta.
- Tras cada respuesta, feedback con `references/criterios-feedback.md`: máximo 3 líneas (qué funcionó · qué faltó · dato del brief a usar).
- En modo difícil: una repregunta si la respuesta fue vaga o sin número.
- Si el founder pide la respuesta ideal: dar los 2–3 puntos clave, no el texto.

## Paso 2B — Voz (chat de Claude)

En Cowork no hay modo voz, solo dictado. Para practicar hablando:
1. Generar el bloque de sesión con `references/sesion-voz.md` (instrucciones + contexto mínimo del brief + preguntas elegidas).
2. Indicar al founder: abrir un chat nuevo en Claude (idealmente en el celular), pegar el bloque, activar el modo voz y empezar.
3. Al terminar, el founder pide el resumen en ese chat y lo pega en Cowork.
4. Con el resumen, seguir al Paso 3.

## Paso 3 — Cierre

Actualizar `pitch/qa.md` con `references/plantilla-qa.md`:
- Fecha, modo y canal.
- Puntaje por pregunta (🟢🟡🔴).
- Temas a reforzar (máximo 3).
- Datos faltantes → derivar a `relevamiento`.
- Preguntas nuevas que conviene cubrir en el deck o el guion.

Actualizar `pitch/estado.md` y dar al founder los 3 temas a reforzar.
